local MapService = require(script.Parent:WaitForChild("MapService"))

MapService.GenerateMap()
