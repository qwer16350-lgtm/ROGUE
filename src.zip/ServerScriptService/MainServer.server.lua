local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

local Shared = ReplicatedStorage:WaitForChild("Shared")

local GameConfig = require(Shared:WaitForChild("GameConfig"))
local EnemyService = require(script.Parent:WaitForChild("EnemyService"))
local WaveService = require(script.Parent:WaitForChild("WaveService"))
local CombatService = require(script.Parent:WaitForChild("CombatService"))
local ProgressionService = require(script.Parent:WaitForChild("ProgressionService"))
local XpPickupService = require(script.Parent:WaitForChild("XpPickupService"))
local HealthPickupService = require(script.Parent:WaitForChild("HealthPickupService"))
local HudSyncService = require(script.Parent:WaitForChild("HudSyncService"))
local PlayerContactDamageService = require(script.Parent:WaitForChild("PlayerContactDamageService"))

local Remotes = ReplicatedStorage:WaitForChild("Remotes")

EnemyService.init(Players, RunService, GameConfig)
PlayerContactDamageService.init(Players, RunService, GameConfig, EnemyService)
ProgressionService.init(Players, ReplicatedStorage, GameConfig)
XpPickupService.init(Players, RunService, ProgressionService, GameConfig)
HealthPickupService.init(Players, RunService, GameConfig)
WaveService.init(Players, RunService, GameConfig, EnemyService, ProgressionService, XpPickupService)
HudSyncService.init(Players, RunService, ProgressionService, WaveService, GameConfig)
WaveService.bindHudPushContext({
	hudSyncService = HudSyncService,
	xpPickupService = XpPickupService,
	healthPickupService = HealthPickupService,
	players = Players,
	progressionService = ProgressionService,
	gameConfig = GameConfig,
})
ProgressionService.setImmediateHudPush(function(player)
	HudSyncService.pushToPlayer(player, ProgressionService, WaveService, GameConfig)
end)
CombatService.init(Players, RunService, GameConfig, EnemyService, ProgressionService, XpPickupService, WaveService, HealthPickupService)

Remotes:WaitForChild("StageFlowRequest").OnServerEvent:Connect(function(player, payload)
	WaveService.onStageFlowRequest(player, payload)
end)

print("[MainServer] Server started")
