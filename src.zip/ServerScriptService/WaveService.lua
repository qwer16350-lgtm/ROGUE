local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerScriptService = game:GetService("ServerScriptService")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local StageData = require(Shared:WaitForChild("StageData"))
local SpawnRules = require(Shared:WaitForChild("SpawnRules"))

-- Stage 전환 시 새 stageIndex 의 biome/marker 로 맵을 재생성하기 위해 참조.
-- 부팅 시점의 Stage 1 맵은 MapBootstrap 이 이미 생성하므로 init()/최초 startStage() 에서는
-- 호출하지 않는다. 오직 handleStageFlowRequest 의 NextStage 흐름에서만 호출.
local MapService = require(ServerScriptService:WaitForChild("Map"):WaitForChild("MapService"))

local WaveService = {}
local DEBUG_STAGE_FLOW = true

local hudRemainingSec = 0
local hudRemainingFloat = 0
local hudSessionActive = false
local hudSessionLengthSeconds = 0

local recordKillImpl = nil

local ctx = {
	players = nil,
	gameConfig = nil,
	enemyService = nil,
	progressionService = nil,
	xpPickupService = nil,
	healthPickupService = nil,
	hudSyncService = nil,
}

local pendingAdvance = {}
local currentStageIndex = 1

local sess = {
	startTime = 0,
	lengthSec = 0,
	active = false,
	bossSpawned = false,
	bossPart = nil,
	killCount = 0,
	lastSpawnTime = 0,
	lastEliteSpawnTime = 0,
	--- startStage 시점에만 갱신. Heartbeat에서 StageData를 다시 읽지 않음.
	spawnProfile = nil,
	--- Resolved once per session via SpawnRules; immutable until next startStage.
	gruntTuning = nil,
}

function WaveService.recordKill()
	if recordKillImpl then
		recordKillImpl()
	end
end

function WaveService.getHudInfo()
	return {
		remaining = hudRemainingSec,
		remainingFloat = hudRemainingFloat,
		active = hudSessionActive,
		sessionLengthSeconds = hudSessionLengthSeconds,
		stageIndex = currentStageIndex,
	}
end

function WaveService.bindHudPushContext(deps)
	ctx.hudSyncService = deps.hudSyncService
	ctx.xpPickupService = deps.xpPickupService
	ctx.healthPickupService = deps.healthPickupService
	ctx.players = deps.players
	ctx.progressionService = deps.progressionService
	ctx.gameConfig = deps.gameConfig
end

function WaveService.init(players, runService, gameConfig, enemyService, progressionService, xpPickupService)
	ctx.players = players
	ctx.gameConfig = gameConfig
	ctx.enemyService = enemyService
	ctx.progressionService = progressionService
	ctx.xpPickupService = xpPickupService

	local resultEvent = ReplicatedStorage:FindFirstChild("SessionResult")
	if not resultEvent then
		resultEvent = Instance.new("RemoteEvent")
		resultEvent.Name = "SessionResult"
		resultEvent.Parent = ReplicatedStorage
	end

	local function buildUpgradesPayload(upgradeCounts)
		local list = {}
		for id, count in pairs(upgradeCounts) do
			if type(count) == "number" and count > 0 then
				table.insert(list, { Id = id, Count = count })
			end
		end
		table.sort(list, function(a, b)
			return a.Id < b.Id
		end)
		return list
	end

	local function pushHudAllPlayers()
		local h = ctx.hudSyncService
		local plrs = ctx.players
		local prog = ctx.progressionService
		local gc = ctx.gameConfig
		if not h or not plrs or not prog or not gc then
			return
		end
		for _, p in ipairs(plrs:GetPlayers()) do
			h.pushToPlayer(p, prog, WaveService, gc)
		end
	end

	local function applyStageSpawnOrigin()
		local enemy = ctx.enemyService
		local gc = ctx.gameConfig
		if not enemy or not gc then
			return
		end
		enemy.setSpawnWorldOffset(StageData.getEnemySpawnOrigin(gc, currentStageIndex))
	end

	local function teleportPlayersToStage()
		local gc = ctx.gameConfig
		local plrs = ctx.players
		if not gc or not plrs then
			return
		end
		local spawnCf = StageData.getPlayerSpawnCFrame(gc, currentStageIndex)
		for _, p in ipairs(plrs:GetPlayers()) do
			local char = p.Character
			local root = char and char:FindFirstChild("HumanoidRootPart")
			if root then
				root.CFrame = spawnCf
			end
		end
	end

	local function clearPendingAdvanceAll()
		local plrs = ctx.players
		if not plrs then
			return
		end
		for _, p in ipairs(plrs:GetPlayers()) do
			pendingAdvance[p] = nil
		end
	end

	local function clearXpOrbs()
		local xp = ctx.xpPickupService
		if xp and xp.clearAllOrbs then
			xp.clearAllOrbs()
		end
	end

	local function clearHealthOrbs()
		local h = ctx.healthPickupService
		if h and h.clearAllOrbs then
			h.clearAllOrbs()
		end
	end

	local function startStage()
		sess.spawnProfile = StageData.getSpawnProfile(gameConfig, currentStageIndex)
		sess.gruntTuning = SpawnRules.resolveGruntTuning(gameConfig, sess.spawnProfile)
		local len = StageData.getSessionDurationSeconds(gameConfig, currentStageIndex)
		sess.lengthSec = len
		hudSessionLengthSeconds = len
		hudRemainingSec = len
		hudRemainingFloat = len
		hudSessionActive = true
		sess.active = true
		sess.bossSpawned = false
		sess.bossPart = nil
		sess.killCount = 0
		sess.startTime = tick()
		sess.lastSpawnTime = tick()
		sess.lastEliteSpawnTime = tick()
		applyStageSpawnOrigin()
		enemyService.clearAllEnemies()
		local startSpawns = gameConfig.EnemyGruntSpawnsPerTick or 1
		if type(startSpawns) ~= "number" or startSpawns < 1 then
			startSpawns = 1
		end
		for _ = 1, startSpawns do
			enemyService.spawnGrunt(gameConfig)
		end
	end

	local function finishSession(bossKilled)
		if not sess.active then
			return
		end
		sess.active = false

		local elapsed = tick() - sess.startTime
		local survivalSeconds = math.floor(elapsed + 0.5)
		local canAdvance = bossKilled == true

		for _, p in ipairs(players:GetPlayers()) do
			if canAdvance then
				pendingAdvance[p] = true
			else
				pendingAdvance[p] = nil
			end
			local prog = progressionService.getHudProgress(p)
			local ups = progressionService.getUpgradeCounts(p)

			resultEvent:FireClient(p, {
				SurvivalSeconds = survivalSeconds,
				KillCount = sess.killCount,
				FinalLevel = prog.level,
				Upgrades = buildUpgradesPayload(ups),
				BossKilled = canAdvance,
				CanAdvance = canAdvance,
			})
		end

		sess.bossPart = nil
		enemyService.clearAllEnemies()
	end

	local function allPlayersDead()
		local list = players:GetPlayers()
		if #list == 0 then
			return false
		end

		for _, p in ipairs(list) do
			local char = p.Character
			if not char then
				return false
			end
			local h = char:FindFirstChildOfClass("Humanoid")
			if not h then
				return false
			end
			if h.Health > 0 then
				return false
			end
		end

		return true
	end

	local function advanceStageIndexIfPossible()
		local maxStage = StageData.getStageCount()
		local before = currentStageIndex
		if currentStageIndex < maxStage then
			currentStageIndex += 1
		end
		if DEBUG_STAGE_FLOW then
			print(string.format("[WaveService] advanceStageIndexIfPossible: %d -> %d (max=%d)", before, currentStageIndex, maxStage))
		end
	end

	local function handleStageFlowRequest(player, payload)
		if not player or not player.Parent then
			return
		end
		local action = type(payload) == "table" and payload.Action or nil

		if action == "Exit" then
			if DEBUG_STAGE_FLOW then
				print(string.format("[WaveService] StageFlowRequest Exit from %s", player.Name))
			end
			-- MVP: 서버는 이 플레이어의 "다음 층" 자격만 해제. 로비/Place 이동 등은 여기서 하지 않음(확장 슬롯).
			-- 결과창 닫기는 클라(ResultClient)에서 처리.
			pendingAdvance[player] = nil
			return
		end

		if action ~= "NextStage" then
			return
		end
		if pendingAdvance[player] ~= true then
			if DEBUG_STAGE_FLOW then
				print(string.format("[WaveService] NextStage rejected: %s pendingAdvance=%s", player.Name, tostring(pendingAdvance[player])))
			end
			return
		end
		if DEBUG_STAGE_FLOW then
			print(string.format("[WaveService] NextStage accepted: %s at stage=%d", player.Name, currentStageIndex))
		end

		local gc = ctx.gameConfig
		local enemy = ctx.enemyService
		local plrs = ctx.players
		if not gc or not enemy or not plrs then
			return
		end

		clearXpOrbs()
		clearHealthOrbs()
		advanceStageIndexIfPossible()
		if DEBUG_STAGE_FLOW then
			print(string.format("[WaveService] restart stage flow: currentStageIndex=%d", currentStageIndex))
			print(string.format("[WaveService] regenerate map for stage=%d", currentStageIndex))
		end
		-- 새 stage 의 biome/marker root 로 맵을 먼저 재생성해야 teleportPlayersToStage 가
		-- 옳은 tile/collision 위에 플레이어를 내려놓을 수 있다.
		MapService.GenerateMap(currentStageIndex)
		clearPendingAdvanceAll()
		applyStageSpawnOrigin()
		teleportPlayersToStage()
		startStage()
		pushHudAllPlayers()
	end

	WaveService.onStageFlowRequest = handleStageFlowRequest

	recordKillImpl = function()
		sess.killCount += 1
	end

	players.PlayerRemoving:Connect(function(p)
		pendingAdvance[p] = nil
	end)

	startStage()

	runService.Heartbeat:Connect(function()
		local now = tick()
		local elapsed = now - sess.startTime

		if sess.active then
			hudRemainingFloat = math.max(0, sess.lengthSec - elapsed)
			hudRemainingSec = math.floor(hudRemainingFloat + 0.5)
			hudSessionActive = true
		else
			hudRemainingFloat = 0
			hudRemainingSec = 0
			hudSessionActive = false
		end

		if not sess.active then
			return
		end

		if sess.bossSpawned and sess.bossPart and not sess.bossPart.Parent then
			finishSession(true)
			return
		end

		if allPlayersDead() then
			finishSession(false)
			return
		end

		if elapsed >= sess.lengthSec and not sess.bossSpawned then
			sess.bossPart = enemyService.spawnBoss(gameConfig)
			sess.bossSpawned = true
			if not sess.bossPart then
				finishSession(false)
			end
			return
		end

		if sess.bossSpawned then
			return
		end

		local effectiveInterval = SpawnRules.computeGruntIntervalSeconds(
			elapsed,
			sess.lengthSec,
			sess.gruntTuning
		)
		local prof = sess.spawnProfile
		local spawnsPerTick = gameConfig.EnemyGruntSpawnsPerTick or 1
		if type(spawnsPerTick) ~= "number" or spawnsPerTick < 1 then
			spawnsPerTick = 1
		end

		if now - sess.lastSpawnTime >= effectiveInterval then
			sess.lastSpawnTime = now
			for _ = 1, spawnsPerTick do
				enemyService.spawnGrunt(gameConfig)
			end
		end

		if prof and prof.EliteGruntEnabled then
			local eliteMul = prof.EliteGruntSpawnIntervalMul
			if type(eliteMul) ~= "number" or eliteMul <= 0 then
				eliteMul = 10
			end
			if now - sess.lastEliteSpawnTime >= effectiveInterval * eliteMul then
				sess.lastEliteSpawnTime = now
				for _ = 1, spawnsPerTick do
					enemyService.spawnGrunt(gameConfig, true, prof.EliteGruntHealthMultiplier)
				end
			end
		end
	end)
end

return WaveService
