local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local UpgradeData = require(Shared:WaitForChild("UpgradeData"))
local WeaponProfiles = require(Shared:WaitForChild("WeaponProfiles"))

local HudSyncService = {}
local DEBUG_STAGE_HUD = true

local hudStateRemote = nil

local SS_KEYS = {
	"ss_common_damage",
	"ss_common_cooldown",
	"ss_sweep_angle",
	"ss_sweep_damage",
	"ss_sweep_range",
	"ss_thrust_damage",
	"ss_thrust_range",
}

local function buildDevCombat(player, progressionService, gameConfig)
	local dbg = gameConfig.Debug
	if type(dbg) ~= "table" or dbg.ShowDevCombatPanel ~= true then
		return nil
	end

	local weaponId = progressionService.getWeaponId(player)
	local upgrades = progressionService.getUpgradeCounts(player)
	if type(upgrades) ~= "table" then
		upgrades = {}
	end
	local startingRelicId = progressionService.getStartingRelicId(player)
	local droppedRelicId = progressionService.getDroppedRelicId(player)
	local weaponGrade = progressionService.getWeaponGrade(player)

	local dc = {
		WeaponId = weaponId,
		WeaponGrade = weaponGrade,
		StartingRelicId = startingRelicId,
		DroppedRelicId = droppedRelicId,
		Run = {
			DefaultWeaponId = gameConfig.Run and gameConfig.Run.DefaultWeaponId,
		},
		Debug = {
			OverrideWeaponId = dbg.OverrideWeaponId,
			ShowAttackRanges = dbg.ShowAttackRanges,
			ShowDevCombatPanel = dbg.ShowDevCombatPanel,
		},
		SwordShieldWeaponDropChance = gameConfig.SwordShieldWeaponDropChance,
		SwordShieldWeaponDropChanceOverride = dbg.SwordShieldWeaponDropChanceOverride,
	}

	for _, k in ipairs(SS_KEYS) do
		local v = upgrades[k]
		dc[k] = type(v) == "number" and math.max(0, math.floor(v + 0.5)) or 0
	end

	if weaponId == "SwordShield" then
		dc.SwordShieldEffective = UpgradeData.getSwordShieldEffectiveCombat(
			gameConfig,
			WeaponProfiles.SwordShield,
			upgrades,
			startingRelicId,
			droppedRelicId,
			weaponGrade
		)
		dc.BasicMagicEffective = nil
	elseif weaponId == "BasicMagic" then
		dc.BasicMagicEffective = UpgradeData.getEffectiveCombatStats(gameConfig, upgrades)
		dc.SwordShieldEffective = nil
	else
		dc.SwordShieldEffective = nil
		dc.BasicMagicEffective = nil
	end

	return dc
end

local function buildPayload(player, progressionService, waveService, gameConfig)
	local waveInfo = waveService.getHudInfo()
	local prog = progressionService.getHudProgress(player)

	local sessionLen = waveInfo.sessionLengthSeconds
	if type(sessionLen) ~= "number" or sessionLen <= 0 then
		sessionLen = gameConfig.SessionDurationSeconds
	end

	local payload = {
		Level = prog.level,
		Xp = prog.xp,
		XpToNext = prog.xpToNext,
		SecondsLeft = waveInfo.remaining,
		SecondsLeftFloat = waveInfo.remainingFloat,
		SessionActive = waveInfo.active,
		SessionLengthSeconds = sessionLen,
		StageIndex = waveInfo.stageIndex or 1,
	}

	local devCombat = buildDevCombat(player, progressionService, gameConfig)
	if devCombat ~= nil then
		payload.DevCombat = devCombat
	end

	return payload
end

function HudSyncService.pushToPlayer(player, progressionService, waveService, gameConfig)
	if not hudStateRemote then
		return
	end
	if not player or not player.Parent then
		return
	end

	local payload = buildPayload(player, progressionService, waveService, gameConfig)
	if DEBUG_STAGE_HUD then
		print(string.format("[HudSyncService] pushToPlayer %s StageIndex=%d SessionActive=%s", player.Name, payload.StageIndex or -1, tostring(payload.SessionActive)))
	end
	hudStateRemote:FireClient(player, payload)
end

function HudSyncService.init(players, runService, progressionService, waveService, gameConfig)
	local syncInterval = gameConfig.HudSyncIntervalSeconds

	hudStateRemote = ReplicatedStorage:FindFirstChild("HudState")
	if not hudStateRemote then
		hudStateRemote = Instance.new("RemoteEvent")
		hudStateRemote.Name = "HudState"
		hudStateRemote.Parent = ReplicatedStorage
	end

	local accumulator = 0

	runService.Heartbeat:Connect(function(dt)
		accumulator += dt
		if accumulator < syncInterval then
			return
		end
		accumulator = 0

		for _, player in ipairs(players:GetPlayers()) do
			local payload = buildPayload(player, progressionService, waveService, gameConfig)
			if DEBUG_STAGE_HUD then
				print(string.format("[HudSyncService] heartbeat push %s StageIndex=%d SessionActive=%s", player.Name, payload.StageIndex or -1, tostring(payload.SessionActive)))
			end
			hudStateRemote:FireClient(player, payload)
		end
	end)
end

return HudSyncService
