local HUDClient = require(script.Parent:WaitForChild("HUDClient"))
local VFXClient = require(script.Parent:WaitForChild("VFXClient"))
local LevelUpClient = require(script.Parent:WaitForChild("LevelUpClient"))
local ResultClient = require(script.Parent:WaitForChild("ResultClient"))

local StageClient = {}

function StageClient.init()
	HUDClient.init()
	VFXClient.init()
	LevelUpClient.init()
	ResultClient.init()
	print("[StageClient] Stage UI clients initialized (HUD, VFX, LevelUp, Result)")
end

return StageClient
